from django.apps import AppConfig


class UsersideConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'userside'
